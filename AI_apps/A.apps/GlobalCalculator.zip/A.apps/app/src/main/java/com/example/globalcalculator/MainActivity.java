package com.example.globalcalculator;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private EditText display;
    private StringBuilder currentExpression;
    private Spinner fromCurrencySpinner, toCurrencySpinner;
    private EditText amountInput;
    private TextView conversionResult, lastUpdated;
    private Button convertButton, refreshButton;
    private GridLayout calculatorGrid;

    private Map<String, Double> exchangeRates;
    private Date lastUpdatedTime;

    private final String[] currencies = {"USD", "EUR", "GBP", "JPY", "CAD", "AUD", "INR"};
    private final String[] currencyNames = {
            "US Dollar", "Euro", "British Pound", "Japanese Yen",
            "Canadian Dollar", "Australian Dollar", "Indian Rupee"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupCalculator();
        setupCurrencyConverter();
        loadFallbackRates();
    }

    private void initializeViews() {
        display = findViewById(R.id.display);
        fromCurrencySpinner = findViewById(R.id.fromCurrency);
        toCurrencySpinner = findViewById(R.id.toCurrency);
        amountInput = findViewById(R.id.amountInput);
        conversionResult = findViewById(R.id.conversionResult);
        lastUpdated = findViewById(R.id.lastUpdated);
        convertButton = findViewById(R.id.convertButton);
        refreshButton = findViewById(R.id.refreshButton);
        calculatorGrid = findViewById(R.id.calculatorGrid);

        currentExpression = new StringBuilder();
        exchangeRates = new HashMap<>();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, currencyNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromCurrencySpinner.setAdapter(adapter);
        toCurrencySpinner.setAdapter(adapter);
        toCurrencySpinner.setSelection(1);

        amountInput.setText("1");
    }

    private void setupCalculator() {
        String[][] buttons = {
                {"C", "/", "×", "-"},
                {"7", "8", "9", "+"},
                {"4", "5", "6", "="},
                {"1", "2", "3", ""},
                {"0", "", ".", ""}
        };

        for (int row = 0; row < buttons.length; row++) {
            for (int col = 0; col < buttons[row].length; col++) {
                String value = buttons[row][col];
                if (!value.isEmpty()) {
                    addCalculatorButton(value, row, col);
                }
            }
        }
    }

    private void addCalculatorButton(String text, int row, int col) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(20);
        button.setPadding(16, 16, 16, 16);

        if (text.matches("[0-9]")) {
            button.setBackgroundColor(0xFFF8F9FA);
        } else if (text.equals("=")) {
            button.setBackgroundColor(0xFF6A11CB);
            button.setTextColor(0xFFFFFFFF);
        } else if (text.equals("C")) {
            button.setBackgroundColor(0xFFFF6B6B);
            button.setTextColor(0xFFFFFFFF);
        } else {
            button.setBackgroundColor(0xFF2575FC);
            button.setTextColor(0xFFFFFFFF);
        }

        button.setOnClickListener(v -> onCalculatorButtonClick(text));

        GridLayout.Spec rowSpec = GridLayout.spec(row);
        GridLayout.Spec colSpec = GridLayout.spec(col);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams(rowSpec, colSpec);
        params.width = 0;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.setMargins(4, 4, 4, 4);
        params.columnSpec = GridLayout.spec(col, 1f);
        button.setLayoutParams(params);

        calculatorGrid.addView(button);
    }

    private void onCalculatorButtonClick(String value) {
        switch (value) {
            case "C":
                currentExpression.setLength(0);
                display.setText("0");
                break;
            case "=":
                calculateResult();
                break;
            case "×":
                if (currentExpression.length() == 0) return;
                currentExpression.append("*");
                display.append("×");
                break;
            default:
                if (display.getText().toString().equals("0") && !value.equals(".")) {
                    display.setText(value);
                    currentExpression.setLength(0);
                    currentExpression.append(value);
                } else {
                    display.append(value);
                    currentExpression.append(value);
                }
                break;
        }
    }

    private void calculateResult() {
        try {
            String expression = currentExpression.toString().replace("×", "*");
            double result = evaluateExpression(expression);
            display.setText(formatResult(result));
            currentExpression.setLength(0);
            currentExpression.append(result);
        } catch (Exception e) {
            display.setText("Error");
            currentExpression.setLength(0);
        }
    }

    private String formatResult(double result) {
        if (result == (long) result) {
            return String.format("%d", (long) result);
        } else {
            return String.format("%.2f", result);
        }
    }

    private double evaluateExpression(String expression) {
        try {
            return new Object() {
                int pos = -1, ch;

                void nextChar() {
                    ch = (++pos < expression.length()) ? expression.charAt(pos) : -1;
                }

                boolean eat(int charToEat) {
                    while (ch == ' ') nextChar();
                    if (ch == charToEat) {
                        nextChar();
                        return true;
                    }
                    return false;
                }

                double parse() {
                    nextChar();
                    double x = parseExpression();
                    if (pos < expression.length()) throw new RuntimeException("Unexpected character");
                    return x;
                }

                double parseExpression() {
                    double x = parseTerm();
                    for (;;) {
                        if (eat('+')) x += parseTerm();
                        else if (eat('-')) x -= parseTerm();
                        else return x;
                    }
                }

                double parseTerm() {
                    double x = parseFactor();
                    for (;;) {
                        if (eat('*')) x *= parseFactor();
                        else if (eat('/')) x /= parseFactor();
                        else return x;
                    }
                }

                double parseFactor() {
                    if (eat('+')) return parseFactor();
                    if (eat('-')) return -parseFactor();

                    double x;
                    int startPos = this.pos;
                    if ((ch >= '0' && ch <= '9') || ch == '.') {
                        while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                        x = Double.parseDouble(expression.substring(startPos, this.pos));
                    } else {
                        throw new RuntimeException("Unexpected character: " + (char)ch);
                    }
                    return x;
                }
            }.parse();
        } catch (Exception e) {
            throw new RuntimeException("Invalid expression");
        }
    }

    private void setupCurrencyConverter() {
        convertButton.setOnClickListener(v -> convertCurrency());
        refreshButton.setOnClickListener(v -> fetchExchangeRates());

        Button swapButton = findViewById(R.id.swapCurrencies);
        swapButton.setOnClickListener(v -> {
            int fromPos = fromCurrencySpinner.getSelectedItemPosition();
            int toPos = toCurrencySpinner.getSelectedItemPosition();
            fromCurrencySpinner.setSelection(toPos);
            toCurrencySpinner.setSelection(fromPos);
        });
    }

    private void convertCurrency() {
        if (exchangeRates.isEmpty()) {
            conversionResult.setText("Exchange rates not loaded. Please refresh.");
            return;
        }

        try {
            String amountText = amountInput.getText().toString();
            if (amountText.isEmpty()) {
                conversionResult.setText("Please enter an amount");
                return;
            }

            double amount = Double.parseDouble(amountText);
            String fromCurrency = currencies[fromCurrencySpinner.getSelectedItemPosition()];
            String toCurrency = currencies[toCurrencySpinner.getSelectedItemPosition()];

            if (fromCurrency.equals(toCurrency)) {
                conversionResult.setText(String.format("%.2f %s = %.2f %s", amount, fromCurrency, amount, toCurrency));
                return;
            }

            if (exchangeRates.containsKey(fromCurrency) && exchangeRates.containsKey(toCurrency)) {
                double fromRate = exchangeRates.get(fromCurrency);
                double toRate = exchangeRates.get(toCurrency);
                double convertedAmount = (amount / fromRate) * toRate;

                String result = String.format("%.2f %s = %.2f %s", amount, fromCurrency, convertedAmount, toCurrency);
                conversionResult.setText(result);
            } else {
                conversionResult.setText("Exchange rate not available for selected currencies");
            }
        } catch (NumberFormatException e) {
            conversionResult.setText("Please enter a valid amount");
        }
    }

    private void fetchExchangeRates() {
        new FetchExchangeRatesTask().execute();
    }

    private class FetchExchangeRatesTask extends AsyncTask<Void, Void, String> {

        @Override
        protected void onPreExecute() {
            conversionResult.setText("Fetching latest exchange rates...");
        }

        @Override
        protected String doInBackground(Void... voids) {
            HttpURLConnection urlConnection = null;
            try {
                URL url = new URL("https://api.frankfurter.app/latest?from=USD");
                urlConnection = (HttpURLConnection) url.openConnection();
                urlConnection.setRequestMethod("GET");
                urlConnection.setConnectTimeout(10000);
                urlConnection.setReadTimeout(10000);

                InputStream inputStream = urlConnection.getInputStream();
                BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuilder stringBuilder = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    stringBuilder.append(line);
                }
                return stringBuilder.toString();

            } catch (Exception e) {
                return null;
            } finally {
                if (urlConnection != null) {
                    urlConnection.disconnect();
                }
            }
        }

        @Override
        protected void onPostExecute(String result) {
            if (result != null) {
                try {
                    JSONObject jsonObject = new JSONObject(result);
                    JSONObject rates = jsonObject.getJSONObject("rates");

                    exchangeRates.clear();
                    exchangeRates.put("USD", 1.0);

                    for (String currency : currencies) {
                        if (rates.has(currency)) {
                            exchangeRates.put(currency, rates.getDouble(currency));
                        }
                    }

                    lastUpdatedTime = new Date();
                    updateLastUpdatedDisplay();
                    conversionResult.setText("Rates updated successfully! Enter amount and convert.");

                } catch (Exception e) {
                    conversionResult.setText("Error parsing data. Using fallback rates.");
                    loadFallbackRates();
                }
            } else {
                conversionResult.setText("Network error. Using fallback rates.");
                loadFallbackRates();
            }
        }
    }

    private void loadFallbackRates() {
        exchangeRates.put("USD", 1.0);
        exchangeRates.put("EUR", 0.85);
        exchangeRates.put("GBP", 0.73);
        exchangeRates.put("JPY", 110.15);
        exchangeRates.put("CAD", 1.25);
        exchangeRates.put("AUD", 1.35);
        exchangeRates.put("INR", 74.5);

        lastUpdatedTime = new Date();
        updateLastUpdatedDisplay();
    }

    private void updateLastUpdatedDisplay() {
        if (lastUpdatedTime != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            lastUpdated.setText("Last updated: " + sdf.format(lastUpdatedTime));
        }
    }
}