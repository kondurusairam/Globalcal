package com.example.globalcalculator;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends AppCompatActivity {

    private EditText display;
    private StringBuilder currentExpression;
    private Spinner fromCurrencySpinner, toCurrencySpinner;
    private EditText amountInput;
    private TextView conversionResult, lastUpdated;
    private Button convertButton, refreshButton;
    private GridLayout calculatorGrid;

    private Map<String, Double> exchangeRates;
    private Date lastUpdatedTime;

    private final String[] currencies = {"USD", "EUR", "GBP", "JPY", "CAD", "AUD", "INR", "CHF", "CNY"};
    private final String[] currencyNames = {
            "US Dollar", "Euro", "British Pound", "Japanese Yen",
            "Canadian Dollar", "Australian Dollar", "Indian Rupee", "Swiss Franc", "Chinese Yuan"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupCalculator();
        setupCurrencyConverter();

        // Start with fallback rates, then try to get live data
        loadFallbackRates();
        fetchExchangeRates(); // Try to get live data
    }

    private void initializeViews() {
        display = findViewById(R.id.display);
        fromCurrencySpinner = findViewById(R.id.fromCurrency);
        toCurrencySpinner = findViewById(R.id.toCurrency);
        amountInput = findViewById(R.id.amountInput);
        conversionResult = findViewById(R.id.conversionResult);
        lastUpdated = findViewById(R.id.lastUpdated);
        convertButton = findViewById(R.id.convertButton);
        refreshButton = findViewById(R.id.refreshButton);
        calculatorGrid = findViewById(R.id.calculatorGrid);

        currentExpression = new StringBuilder();
        exchangeRates = new HashMap<>();

        // Setup currency spinners
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item, currencyNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        fromCurrencySpinner.setAdapter(adapter);
        toCurrencySpinner.setAdapter(adapter);
        toCurrencySpinner.setSelection(1); // Default to EUR

        amountInput.setText("1.00");
    }

    private void setupCalculator() {
        String[][] buttons = {
                {"C", "/", "×", "-"},
                {"7", "8", "9", "+"},
                {"4", "5", "6", "="},
                {"1", "2", "3", ""},
                {"0", "", ".", ""}
        };

        for (int row = 0; row < buttons.length; row++) {
            for (int col = 0; col < buttons[row].length; col++) {
                String value = buttons[row][col];
                if (!value.isEmpty()) {
                    addCalculatorButton(value, row, col);
                }
            }
        }
    }

    private void addCalculatorButton(String text, int row, int col) {
        Button button = new Button(this);
        button.setText(text);
        button.setTextSize(20);
        button.setPadding(16, 16, 16, 16);

        // Set button colors
        if (text.matches("[0-9]")) {
            button.setBackgroundColor(0xFFF8F9FA);
        } else if (text.equals("=")) {
            button.setBackgroundColor(0xFF6A11CB);
            button.setTextColor(0xFFFFFFFF);
        } else if (text.equals("C")) {
            button.setBackgroundColor(0xFFFF6B6B);
            button.setTextColor(0xFFFFFFFF);
        } else {
            button.setBackgroundColor(0xFF2575FC);
            button.setTextColor(0xFFFFFFFF);
        }

        button.setOnClickListener(v -> onCalculatorButtonClick(text));

        GridLayout.Spec rowSpec = GridLayout.spec(row);
        GridLayout.Spec colSpec = GridLayout.spec(col);
        GridLayout.LayoutParams params = new GridLayout.LayoutParams(rowSpec, colSpec);
        params.width = 0;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.setMargins(4, 4, 4, 4);
        params.columnSpec = GridLayout.spec(col, 1f);
        button.setLayoutParams(params);

        calculatorGrid.addView(button);
    }

    private void onCalculatorButtonClick(String value) {
        switch (value) {
            case "C":
                currentExpression.setLength(0);
                display.setText("0");
                break;
            case "=":
                calculateResult();
                break;
            case "×":
                if (currentExpression.length() == 0) return;
                currentExpression.append("*");
                display.append("×");
                break;
            default:
                if (display.getText().toString().equals("0") && !value.equals(".")) {
                    display.setText(value);
                    currentExpression.setLength(0);
                    currentExpression.append(value);
                } else {
                    display.append(value);
                    currentExpression.append(value);
                }
                break;
        }
    }

    private void calculateResult() {
        try {
            String expression = currentExpression.toString().replace("×", "*");
            double result = evaluateExpression(expression);
            display.setText(formatResult(result));
            currentExpression.setLength(0);
            currentExpression.append(result);
        } catch (Exception e) {
            display.setText("Error");
            currentExpression.setLength(0);
        }
    }

    private String formatResult(double result) {
        if (result == (long) result) {
            return String.format("%d", (long) result);
        } else {
            return String.format("%.2f", result);
        }
    }

    private double evaluateExpression(String expression) {
        try {
            return new Object() {
                int pos = -1, ch;

                void nextChar() {
                    ch = (++pos < expression.length()) ? expression.charAt(pos) : -1;
                }

                boolean eat(int charToEat) {
                    while (ch == ' ') nextChar();
                    if (ch == charToEat) {
                        nextChar();
                        return true;
                    }
                    return false;
                }

                double parse() {
                    nextChar();
                    double x = parseExpression();
                    if (pos < expression.length()) throw new RuntimeException("Unexpected character");
                    return x;
                }

                double parseExpression() {
                    double x = parseTerm();
                    for (;;) {
                        if (eat('+')) x += parseTerm();
                        else if (eat('-')) x -= parseTerm();
                        else return x;
                    }
                }

                double parseTerm() {
                    double x = parseFactor();
                    for (;;) {
                        if (eat('*')) x *= parseFactor();
                        else if (eat('/')) x /= parseFactor();
                        else return x;
                    }
                }

                double parseFactor() {
                    if (eat('+')) return parseFactor();
                    if (eat('-')) return -parseFactor();

                    double x;
                    int startPos = this.pos;
                    if ((ch >= '0' && ch <= '9') || ch == '.') {
                        while ((ch >= '0' && ch <= '9') || ch == '.') nextChar();
                        x = Double.parseDouble(expression.substring(startPos, this.pos));
                    } else {
                        throw new RuntimeException("Unexpected character: " + (char)ch);
                    }
                    return x;
                }
            }.parse();
        } catch (Exception e) {
            throw new RuntimeException("Invalid expression");
        }
    }

    private void setupCurrencyConverter() {
        convertButton.setOnClickListener(v -> convertCurrency());
        refreshButton.setOnClickListener(v -> fetchExchangeRates());

        Button swapButton = findViewById(R.id.swapCurrencies);
        swapButton.setOnClickListener(v -> {
            int fromPos = fromCurrencySpinner.getSelectedItemPosition();
            int toPos = toCurrencySpinner.getSelectedItemPosition();
            fromCurrencySpinner.setSelection(toPos);
            toCurrencySpinner.setSelection(fromPos);
        });
    }

    private void convertCurrency() {
        if (exchangeRates.isEmpty()) {
            conversionResult.setText("Exchange rates not loaded. Please refresh.");
            return;
        }

        try {
            String amountText = amountInput.getText().toString();
            if (amountText.isEmpty()) {
                conversionResult.setText("Please enter an amount");
                return;
            }

            double amount = Double.parseDouble(amountText);
            String fromCurrency = currencies[fromCurrencySpinner.getSelectedItemPosition()];
            String toCurrency = currencies[toCurrencySpinner.getSelectedItemPosition()];

            if (fromCurrency.equals(toCurrency)) {
                conversionResult.setText(String.format("%.2f %s = %.2f %s", amount, fromCurrency, amount, toCurrency));
                return;
            }

            if (exchangeRates.containsKey(fromCurrency) && exchangeRates.containsKey(toCurrency)) {
                // Convert via USD as base currency
                double amountInUSD = amount / exchangeRates.get(fromCurrency);
                double convertedAmount = amountInUSD * exchangeRates.get(toCurrency);

                double rate = convertedAmount / amount;
                String result = String.format("%.2f %s = %.2f %s\nRate: 1 %s = %.4f %s",
                        amount, fromCurrency, convertedAmount, toCurrency,
                        fromCurrency, rate, toCurrency);
                conversionResult.setText(result);
            } else {
                conversionResult.setText("Exchange rate not available for selected currencies");
            }
        } catch (NumberFormatException e) {
            conversionResult.setText("Please enter a valid amount");
        }
    }

    private void fetchExchangeRates() {
        new FetchExchangeRatesTask().execute();
    }

    private class FetchExchangeRatesTask extends AsyncTask<Void, Void, Map<String, Double>> {

        @Override
        protected void onPreExecute() {
            conversionResult.setText("🔄 Fetching latest exchange rates...");
            refreshButton.setEnabled(false);
        }

        @Override
        protected Map<String, Double> doInBackground(Void... voids) {
            Map<String, Double> rates = new HashMap<>();

            // Try multiple free APIs with fallback
            String[] apis = {
                    "https://api.frankfurter.app/latest?from=USD",
                    "https://api.exchangerate.host/latest?base=USD",
                    "https://open.er-api.com/v6/latest/USD"
            };

            for (String apiUrl : apis) {
                try {
                    URL url = new URL(apiUrl);
                    HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                    connection.setRequestMethod("GET");
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(10000);

                    if (connection.getResponseCode() == 200) {
                        InputStream inputStream = connection.getInputStream();
                        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                        StringBuilder response = new StringBuilder();
                        String line;

                        while ((line = reader.readLine()) != null) {
                            response.append(line);
                        }

                        JSONObject jsonResponse = new JSONObject(response.toString());
                        JSONObject ratesObject = jsonResponse.getJSONObject("rates");

                        // Add all available rates
                        rates.put("USD", 1.0);
                        for (String currency : currencies) {
                            if (ratesObject.has(currency)) {
                                rates.put(currency, ratesObject.getDouble(currency));
                            }
                        }

                        // If we got at least 3 currencies, consider it successful
                        if (rates.size() >= 4) {
                            return rates;
                        }
                    }

                    connection.disconnect();
                } catch (Exception e) {
                    // Try next API
                    continue;
                }
            }

            return null; // All APIs failed
        }

        @Override
        protected void onPostExecute(Map<String, Double> result) {
            refreshButton.setEnabled(true);

            if (result != null && !result.isEmpty()) {
                exchangeRates.clear();
                exchangeRates.putAll(result);
                lastUpdatedTime = new Date();
                updateLastUpdatedDisplay();

                // Show success with sample conversion
                conversionResult.setText("✅ Rates updated successfully!\nTap Convert to see live rates");

                // Auto-convert with current amount to demonstrate
                try {
                    double amount = Double.parseDouble(amountInput.getText().toString());
                    if (amount > 0) {
                        convertCurrency();
                    }
                } catch (NumberFormatException e) {
                    // Ignore, user will manually convert
                }

            } else {
                // All APIs failed, use fallback
                loadFallbackRates();
                conversionResult.setText("⚠️ Using fallback rates (Live data unavailable)\nRates are approximate");
            }
        }
    }

    private void loadFallbackRates() {
        // More realistic fallback rates (approximate values)
        exchangeRates.put("USD", 1.0);
        exchangeRates.put("EUR", 0.92);
        exchangeRates.put("GBP", 0.79);
        exchangeRates.put("JPY", 148.50);
        exchangeRates.put("CAD", 1.35);
        exchangeRates.put("AUD", 1.52);
        exchangeRates.put("INR", 83.20);
        exchangeRates.put("CHF", 0.88);
        exchangeRates.put("CNY", 7.18);

        lastUpdatedTime = new Date();
        updateLastUpdatedDisplay();
    }

    private void updateLastUpdatedDisplay() {
        if (lastUpdatedTime != null) {
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String source = exchangeRates.get("EUR") == 0.92 ? "Fallback" : "Live";
            lastUpdated.setText(String.format("Last updated: %s (%s)", sdf.format(lastUpdatedTime), source));
        }
    }
}